import 'package:firebase_core/firebase_core.dart';
import 'package:flash_tweet/chat/main.dart';
import 'package:flash_tweet/login/main.dart';
import 'package:flash_tweet/registration/main.dart';
import 'package:flutter/material.dart';
import 'welcome/main.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(FlashTweet());
}

class FlashTweet extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: WelcomeScreen.id,
      routes: {
        WelcomeScreen.id: (context) => WelcomeScreen(),
        LoginScreen.id: (context) => LoginScreen(),
        RegistrationScreen.id: (context) => RegistrationScreen(),
        ChatScreen.id: (context) => ChatScreen(),
      },
      // theme: ThemeData.dark().copyWith(
      //   textTheme: TextTheme(
      //     bodyText1: TextStyle(color: Colors.black54),
      //   ),

      // ),
      // home: WelcomeScreen(),
    );
  }
}
